module Daniel.Ryszkowski.Java.Wroclaw {
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.annotation;

    exports org.daniel.ryszkowski.java.ocadoApi;
}